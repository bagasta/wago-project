Describe your PR and link to any relevant issues. 

I have:
 - [ ] Added tests covering the bug / feature 
 - [ ] Updated any relevant documentation
