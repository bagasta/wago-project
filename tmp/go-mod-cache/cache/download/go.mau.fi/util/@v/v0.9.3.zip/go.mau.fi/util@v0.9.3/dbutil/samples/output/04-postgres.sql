INSERT INTO foo VALUES ('meow', '{}');
