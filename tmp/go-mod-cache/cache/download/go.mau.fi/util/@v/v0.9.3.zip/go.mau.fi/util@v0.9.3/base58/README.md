base58
==========

This is a copy of <https://github.com/btcsuite/btcd/tree/master/btcutil/base58>.

## License

Package base58 is licensed under the [copyfree](http://copyfree.org) ISC
License.
