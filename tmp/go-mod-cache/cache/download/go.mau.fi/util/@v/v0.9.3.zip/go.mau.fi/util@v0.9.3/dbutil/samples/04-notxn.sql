-- v4: Sample outside transaction
-- transaction: off

INSERT INTO foo VALUES ('meow', '{}');
