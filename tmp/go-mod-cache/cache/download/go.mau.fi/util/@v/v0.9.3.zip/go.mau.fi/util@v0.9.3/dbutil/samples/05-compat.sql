-- v5 (compatible with v3+): Sample backwards-compatible upgrade

INSERT INTO foo VALUES ('meow 2', '{}');
