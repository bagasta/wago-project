// Package record provides the state and record of a group session.
package record
