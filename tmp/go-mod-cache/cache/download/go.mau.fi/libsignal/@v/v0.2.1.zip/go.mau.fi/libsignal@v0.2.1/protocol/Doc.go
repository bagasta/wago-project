// Package protocol provides address, group, and message structures that
// the Signal protocol uses for sending encrypted messages.
package protocol
