// Package store provides the storage interfaces for storing the state of
// ongoing double ratchet sessions and keys.
package store
