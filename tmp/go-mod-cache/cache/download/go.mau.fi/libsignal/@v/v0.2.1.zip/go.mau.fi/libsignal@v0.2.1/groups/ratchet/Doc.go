// Package ratchet provides the methods necessary to establish a ratchet
// session for group messaging.
package ratchet
