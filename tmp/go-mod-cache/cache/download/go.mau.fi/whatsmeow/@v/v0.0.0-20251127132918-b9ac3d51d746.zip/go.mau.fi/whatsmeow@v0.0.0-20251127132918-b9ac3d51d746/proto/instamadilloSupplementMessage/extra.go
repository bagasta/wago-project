package instamadilloSupplementMessage

func (*SupplementMessagePayload) IsMessageApplicationSub() {}
