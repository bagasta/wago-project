---
name: Open issue
about: For bug reports and feature requests directly related to whatsmeow

---

<!--
Do not open issues for questions!
Issues are only for bug reports and feature requests.

Questions belong in the Matrix room or on GitHub Discussions.
-->
