package waMultiDevice

func (*MultiDevice) IsMessageApplicationSub() {}
